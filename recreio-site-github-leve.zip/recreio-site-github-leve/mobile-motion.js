(() => {
  const mobile = window.matchMedia("(max-width: 820px)");
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (!mobile.matches || reduced.matches) return;

  document.documentElement.classList.add("mobile-motion-ready");

  const selectors = [
    ".section-heading h2",
    ".section-heading > p",
    ".flavor-card",
    ".flavor-callout",
    ".news-section article",
    ".game-intro h2",
    ".game-intro > p",
    ".game-cabinet",
    ".story-photo",
    ".story-mascot",
    ".story-copy-site h2",
    ".story-copy-site > p",
    ".story-milestones span",
    ".store-card",
    ".waiting-section > img",
    ".waiting-section h2",
    ".waiting-notes span",
    ".faq-section h2",
    ".faq-section img",
    ".faq-list details",
    ".contact-copy-site h2",
    ".contact-character img",
    ".site-footer > *"
  ];

  const elements = [...document.querySelectorAll(selectors.join(","))];
  elements.forEach((element, index) => {
    element.classList.add("mm-reveal");
    element.style.setProperty("--mm-delay", `${(index % 4) * 65}ms`);
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("mm-visible");
      observer.unobserve(entry.target);
    });
  }, { rootMargin: "0px 0px -8%", threshold: .08 });

  elements.forEach((element) => observer.observe(element));

  const tappables = document.querySelectorAll(".site-button, .store-copy a, .faq-list summary");
  tappables.forEach((element) => {
    element.addEventListener("pointerdown", () => element.classList.add("mm-tapped"), { passive: true });
    ["pointerup", "pointercancel", "pointerleave"].forEach((eventName) => {
      element.addEventListener(eventName, () => element.classList.remove("mm-tapped"), { passive: true });
    });
  });
})();
