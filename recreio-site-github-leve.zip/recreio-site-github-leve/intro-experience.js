(() => {
  const root = document.documentElement;
  if (document.getElementById("recreio-intro")) return;

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const base = new URL("./", document.currentScript.src).pathname;
  const poses = [
    { image: "brand/poses/reio-sorvete.webp", label: "Pose 01 · Casquinha", flavor: "Um clássico para abrir os trabalhos" },
    { image: "brand/poses/reio-acai.webp", label: "Pose 02 · Açaí", flavor: "Energia gelada em close" },
    { image: "brand/poses/reio-milkshake.webp", label: "Pose 03 · Milkshake", flavor: "Cremoso, chique e irresistível" },
    { image: "brand/poses/reio-satisfeito.webp", label: "Pose 04 · Felicidade", flavor: "Aquele momento: nossa, que delícia" },
    { image: "brand/poses/reio-dancando.webp", label: "Pose 05 · Recreio", flavor: "Pronto. Agora pode entrar dançando" }
  ];

  poses.forEach(({ image }) => {
    const preload = new Image();
    preload.src = base + image;
  });

  const intro = document.createElement("section");
  intro.id = "recreio-intro";
  intro.className = "recreio-intro";
  intro.setAttribute("aria-label", "Abertura animada da Recreio Sorvetes");
  intro.innerHTML = `
    <div class="ri-grain" aria-hidden="true"></div>
    <div class="ri-topbar">
      <img class="ri-logo" src="${base}brand/logo-recreio-header.png" alt="Recreio Sorvetes">
      <button class="ri-skip" type="button">Pular abertura →</button>
    </div>
    <div class="ri-copy">
      <div class="ri-eyebrow">Ensaio especial · coleção gelada</div>
      <h1 class="ri-title"><span>Pose.</span><span>Prova.</span><span><em>Recreio.</em></span></h1>
      <p class="ri-caption" aria-live="polite"><span>Pose 01</span> · Um clássico para abrir os trabalhos</p>
    </div>
    <div class="ri-stage" aria-hidden="true">
      <div class="ri-camera-corners"></div>
      <div class="ri-frame">
        <img class="ri-pose is-current" src="${base}${poses[0].image}" alt="">
        <div class="ri-photo-label">${poses[0].label}</div>
      </div>
    </div>
    <i class="ri-scoop" style="left:7%;top:74%;background:#ff92b9;--duration:4.8s"></i>
    <i class="ri-scoop" style="left:45%;top:7%;background:#72d8aa;--duration:5.7s;--delay:-1.8s"></i>
    <i class="ri-scoop" style="right:3%;top:19%;background:#8cb8ff;--duration:4.4s;--delay:-.7s"></i>
    <i class="ri-sprinkle" style="left:4%;top:39%;--color:#ff6173;--duration:3.1s"></i>
    <i class="ri-sprinkle" style="left:40%;bottom:11%;--color:#082f9b;--duration:4s;--delay:-1s"></i>
    <i class="ri-sprinkle" style="right:9%;top:54%;--color:#ffc94f;--duration:3.7s;--delay:-2s"></i>
    <i class="ri-sprinkle" style="right:40%;top:13%;--color:#ff6173;--duration:3.4s;--delay:-1.3s"></i>
    <b class="ri-star" style="left:47%;top:28%;--delay:-.4s">✦</b>
    <b class="ri-star" style="right:5%;bottom:20%;--delay:-1.1s">✦</b>
    <div class="ri-flash" aria-hidden="true"></div>
    <div class="ri-counter">01 / 05</div>
    <div class="ri-progress" aria-hidden="true"><span></span></div>
  `;

  document.body.prepend(intro);
  const frame = intro.querySelector(".ri-frame");
  const caption = intro.querySelector(".ri-caption");
  const counter = intro.querySelector(".ri-counter");
  const flash = intro.querySelector(".ri-flash");
  const skip = intro.querySelector(".ri-skip");
  let current = 0;
  let finished = false;
  const timers = [];

  const triggerFlash = () => {
    flash.classList.remove("is-flashing");
    void flash.offsetWidth;
    flash.classList.add("is-flashing");
  };

  const showPose = (index) => {
    if (finished || index === current) return;
    const previous = frame.querySelector(".ri-pose.is-current");
    previous?.classList.replace("is-current", "is-leaving");

    const next = document.createElement("img");
    next.className = "ri-pose is-current";
    next.src = base + poses[index].image;
    next.alt = "";
    frame.prepend(next);

    const oldLabel = frame.querySelector(".ri-photo-label");
    oldLabel?.remove();
    const label = document.createElement("div");
    label.className = "ri-photo-label";
    label.textContent = poses[index].label;
    frame.append(label);

    caption.innerHTML = `<span>${poses[index].label.split(" · ")[0]}</span> · ${poses[index].flavor}`;
    counter.textContent = `${String(index + 1).padStart(2, "0")} / 05`;
    current = index;
    triggerFlash();
    timers.push(window.setTimeout(() => previous?.remove(), 500));
  };

  const finish = () => {
    if (finished) return;
    finished = true;
    timers.forEach(window.clearTimeout);
    root.classList.add("recreio-intro-revealing");
    intro.classList.add("is-leaving");
    window.setTimeout(() => {
      intro.remove();
      root.classList.remove("recreio-intro-pending", "recreio-intro-revealing");
      window.dispatchEvent(new CustomEvent("recreio:intro-complete"));
    }, reducedMotion ? 80 : 1100);
  };

  skip.addEventListener("click", finish);
  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") finish();
  }, { once: true });

  if (reducedMotion) {
    timers.push(window.setTimeout(finish, 900));
    return;
  }

  [1, 2, 3, 4].forEach((index) => {
    timers.push(window.setTimeout(() => showPose(index), 1080 * index));
  });
  timers.push(window.setTimeout(finish, 6400));
})();
